<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Inscription - Garage</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>

    <header>
        <a href="index.php"><div class="logo">🚗</div></a>
        <form action="traitement.php" method="GET" style="display: inline-block; margin-left: 20px;">
            <input type="text" name="recherche" placeholder="Rechercher un véhicule">
            <button type="submit">Recherchr</button>
        </form>
    </header>

    <nav>
        <a href="index.php">Accueil</a>
        <a href="formulaire.php">Inscription</a>
        <a href="#">Nos véhicule</a>
        <a href="#">Contact</a>
    </nav>

    <main>
        <h2>Formulaire d'inscription</h2>
        <form action="traitement.php" method="POST">

            <label for="nom">Nom :</label><br>
            <input type="text" name="nom" id="nom" required><br><br>

            <label for="prenom">Prénom :</label><br>
            <input type="text" name="prenom" id="prenom"><br><br>

            <label for="email">Email :</label><br>
            <input type="email" name="email" id="email" required><br><br>

            <label for="confirm_email">Confirmation Email :</label><br>
            <input type="email" name="confirm_email" id="confirm_email" required><br><br>

            <button type="submit">Envoyer</button>
        </form>
    </main>

    <footer>

    </footer>
</body>
</html>
