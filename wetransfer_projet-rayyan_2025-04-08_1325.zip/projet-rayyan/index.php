<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Garage de Location</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>

    <header>
        <a href="index.php"><div class="logo">🚗</div></a>

        <form action="traitement.php" method="GET" style="display: inline-block; margin-left: 20px;">
            <input type="text" name="recherche" placeholder="Rechercher un véhicule">
            <button type="submit">Rechercher</button>
        </form>
    </header>

    <nav>
        <a href="index.php">Accueil</a>
        <a href="formulaire.php">Inscription</a>
        <a href="#">Nos véhicules</a>
        <a href="#">Contact</a>
    </nav>

    <main>
        <h1>Accueil <br> Bienvenue sur notre site de location de voitures !</h1>
        <p>Choisissez parmi une large gamme de véhicules à louer.</p>
    </main>

    <footer>

    </footer>
</body>
</html>
